# storage.py
import json
from pathlib import Path

SCOREFILE = Path("scores.json")

def load_scores():
    if not SCOREFILE.exists():
        return []
    try:
        with SCOREFILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_score(name, score):
    scores = load_scores()
    scores.append({"name": name, "score": score})
    # keep highest first
    scores.sort(key=lambda x: x["score"], reverse=True)
    try:
        with SCOREFILE.open("w", encoding="utf-8") as f:
            json.dump(scores, f, indent=2)
    except Exception as e:
        print("Warning: couldn't save score:", e)
