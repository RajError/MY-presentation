# questions.py
# Contains the quiz questions list.

QUESTIONS = [
    {
        "q": "What is the keyword to define a function in Python?",
        "choices": ["A) func", "B) def", "C) function", "D) lambda"],
        "answer": "B"
    },
    {
        "q": "Which data type is used to store text?",
        "choices": ["A) int", "B) float", "C) str", "D) bool"],
        "answer": "C"
    },
    {
        "q": "What does `len()` return for a list?",
        "choices": ["A) number of elements", "B) last element", "C) sum", "D) type"],
        "answer": "A"
    },
    {
        "q": "Which operator is used for exponentiation?",
        "choices": ["A) ^", "B) **", "C) //", "D) %"],
        "answer": "B"
    },
    {
        "q": "How do you start a comment in Python?",
        "choices": ["A) //", "B) <!--", "C) #", "D) /*"],
        "answer": "C"
    },
]
