# utils.py
import os
import sys

def clear_screen():
    """Clear terminal screen (works on Windows, macOS, Linux)."""
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

def get_choice(prompt, valid):
    """
    Prompt until user enters a valid single-character choice from valid (list of uppercase letters).
    Returns uppercase letter.
    """
    while True:
        choice = input(prompt).strip().upper()
        if choice in valid:
            return choice
        print(f"Please enter one of {', '.join(valid)}.")

def pause(msg="Press Enter to continue..."):
    try:
        input(msg)
    except KeyboardInterrupt:
        print()
        sys.exit(0)
